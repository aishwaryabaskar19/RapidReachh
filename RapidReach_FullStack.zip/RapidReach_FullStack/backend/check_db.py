from database import db, Parcel
from app import app

def check_database():
    with app.app_context():
        try:
            # Check if we can connect to the database
            db.engine.connect()
            print("Successfully connected to the database!")
            
            # Check if the Parcel table exists
            if Parcel.__table__.exists(db.engine):
                print("Parcel table exists!")
                
                # Count parcels
                count = Parcel.query.count()
                print(f"Number of parcels in database: {count}")
                
                # List all parcels
                parcels = Parcel.query.all()
                print("\nParcels in database:")
                for parcel in parcels:
                    print(f"- {parcel.tracking_id}: {parcel.status} at {parcel.current_location}")
            else:
                print("Parcel table does not exist!")
                
        except Exception as e:
            print(f"Error: {str(e)}")

if __name__ == "__main__":
    check_database() 