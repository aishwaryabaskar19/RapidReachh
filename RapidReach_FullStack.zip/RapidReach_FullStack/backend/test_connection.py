import psycopg2

def test_connection():
    try:
        # Try to connect to PostgreSQL
        conn = psycopg2.connect(
            dbname="rapidreach",
            user="postgres",
            password="aishu19",
            host="localhost",
            port="5432"
        )
        print("Successfully connected to PostgreSQL!")
        
        # Create a cursor
        cur = conn.cursor()
        
        # Test if we can execute a query
        cur.execute("SELECT version();")
        version = cur.fetchone()
        print("PostgreSQL version:", version)
        
        # Close the connection
        cur.close()
        conn.close()
        
    except Exception as e:
        print("Error connecting to PostgreSQL:", str(e))

if __name__ == "__main__":
    test_connection() 