from flask import Blueprint, jsonify, request
from database import Review, db

reviews_bp = Blueprint('reviews', __name__, url_prefix='/api/reviews')

@reviews_bp.route('/<tracking_id>', methods=['GET'])
def get_reviews(tracking_id):
    reviews = Review.query.filter_by(tracking_id=tracking_id).all()
    return jsonify([{'user_name': r.user_name, 'rating': r.rating, 'comment': r.comment, 'created_at': r.created_at.isoformat()} for r in reviews])

@reviews_bp.route('/<tracking_id>', methods=['POST'])
def post_review(tracking_id):
    data = request.json
    review = Review(tracking_id=tracking_id, user_name=data['user_name'], rating=data['rating'], comment=data['comment'])
    db.session.add(review)
    db.session.commit()
    return jsonify({'message': 'Review submitted'}), 201