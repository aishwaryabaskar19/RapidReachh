from flask import Blueprint, request, jsonify
from database import SupportMessage, db

chat_bp = Blueprint('chat', __name__, url_prefix='/api/chat')

def chatbot_response(user_msg):
    # Placeholder for actual chatbot logic
    return "Thanks for reaching out. How can I help you with your parcel?"

@chat_bp.route('/', methods=['POST'])
def chat():
    user_msg = request.json.get('message')
    response_text = chatbot_response(user_msg)

    support_msg = SupportMessage(sender='user', message=user_msg)
    support_msg_bot = SupportMessage(sender='bot', message=response_text)
    db.session.add_all([support_msg, support_msg_bot])
    db.session.commit()

    return jsonify({'response': response_text})