from flask import Blueprint, jsonify
from database import Parcel, db
from datetime import datetime

tracking_bp = Blueprint('tracking', __name__, url_prefix='/api/tracking')

@tracking_bp.route('/<tracking_id>', methods=['GET'])
def get_tracking(tracking_id):
    print(f"Received tracking request for ID: {tracking_id}")
    try:
        parcel = Parcel.query.filter_by(tracking_id=tracking_id).first()
        if not parcel:
            print(f"No parcel found with tracking ID: {tracking_id}")
            return jsonify({'error': 'Tracking ID not found'}), 404

        print(f"Found parcel: {parcel.tracking_id}, Status: {parcel.status}")
        return jsonify({
            'tracking_id': parcel.tracking_id,
            'status': parcel.status,
            'current_location': parcel.current_location,
            'last_updated': parcel.last_updated.isoformat() if parcel.last_updated else datetime.now().isoformat(),
            'eta': parcel.eta.isoformat() if parcel.eta else datetime.now().isoformat()
        })
    except Exception as e:
        print(f"Error processing tracking request: {str(e)}")
        return jsonify({'error': str(e)}), 500

# Add a test endpoint
@tracking_bp.route('/test', methods=['GET'])
def test_tracking():
    return jsonify({'message': 'Tracking endpoint is working!'})