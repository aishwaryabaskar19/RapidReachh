from database import db, Parcel, Review, SupportMessage
from datetime import datetime, timedelta

def seed_database():
    # Clear existing data
    SupportMessage.query.delete()
    Review.query.delete()
    Parcel.query.delete()
    
    # Create sample parcels
    parcels = [
        Parcel(
            tracking_id='RR123456789IN',
            current_location='Mumbai Hub',
            status='In Transit',
            last_updated=datetime.utcnow(),
            eta=datetime.utcnow() + timedelta(days=2)
        ),
        Parcel(
            tracking_id='RR987654321IN',
            current_location='Delhi Sorting Center',
            status='Out for Delivery',
            last_updated=datetime.utcnow(),
            eta=datetime.utcnow() + timedelta(hours=4)
        ),
        Parcel(
            tracking_id='RR456789123IN',
            current_location='Bangalore Hub',
            status='Delivered',
            last_updated=datetime.utcnow() - timedelta(days=1),
            eta=datetime.utcnow() - timedelta(days=1)
        )
    ]
    
    # Create sample reviews
    reviews = [
        Review(
            tracking_id='RR123456789IN',
            user_name='John Doe',
            rating=5,
            comment='Excellent service! Package arrived on time.'
        ),
        Review(
            tracking_id='RR987654321IN',
            user_name='Jane Smith',
            rating=4,
            comment='Good service, but could be faster.'
        )
    ]
    
    # Create sample support messages
    support_messages = [
        SupportMessage(
            sender='user',
            message='When will my package arrive?',
            created_at=datetime.utcnow() - timedelta(hours=2)
        ),
        SupportMessage(
            sender='bot',
            message='Your package is currently in transit and will arrive in 2 days.',
            created_at=datetime.utcnow() - timedelta(hours=1)
        )
    ]
    
    # Add all data to the database
    db.session.add_all(parcels)
    db.session.add_all(reviews)
    db.session.add_all(support_messages)
    
    # Commit the changes
    db.session.commit()
    
    print("Database seeded successfully!")

if __name__ == '__main__':
    seed_database() 