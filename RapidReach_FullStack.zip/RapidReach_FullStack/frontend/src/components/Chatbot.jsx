import React, { useState } from 'react';
import './Chatbot.css';

const Chatbot = () => {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [language, setLanguage] = useState('en');

  const translations = {
    en: {
      placeholder: 'Type your message...',
      send: 'Send',
      language: 'Language',
      welcome: 'Welcome to RapidReach Support! How can I help you today?'
    },
    hi: {
      placeholder: 'अपना संदेश लिखें...',
      send: 'भेजें',
      language: 'भाषा',
      welcome: 'रैपिडरीच सपोर्ट में आपका स्वागत है! मैं आपकी कैसे मदद कर सकता हूं?'
    },
    ta: {
      placeholder: 'உங்கள் செய்தியை உள்ளிடவும்...',
      send: 'அனுப்பு',
      language: 'மொழி',
      welcome: 'ரேபிட்ரீச் ஆதரவுக்கு வரவேற்கிறோம்! இன்று நான் உங்களுக்கு எவ்வாறு உதவ முடியும்?'
    },
    te: {
      placeholder: 'మీ సందేశాన్ని టైప్ చేయండి...',
      send: 'పంపండి',
      language: 'భాష',
      welcome: 'రేపిడ్రీచ్ సపోర్ట్‌కు స్వాగతం! నేను ఈరోజు మీకు ఎలా సహాయం చేయగలను?'
    },
    kn: {
      placeholder: 'ನಿಮ್ಮ ಸಂದೇಶವನ್ನು ಟೈಪ್ ಮಾಡಿ...',
      send: 'ಕಳುಹಿಸಿ',
      language: 'ಭಾಷೆ',
      welcome: 'ರ್ಯಾಪಿಡ್ರೀಚ್ ಸಪೋರ್ಟ್‌ಗೆ ಸ್ವಾಗತ! ಇಂದು ನಾನು ನಿಮಗೆ ಹೇಗೆ ಸಹಾಯ ಮಾಡಬಹುದು?'
    }
  };

  const handleSend = async (e) => {
    e.preventDefault();
    if (!input.trim()) return;

    const userMessage = { text: input, sender: 'user' };
    setMessages(prev => [...prev, userMessage]);
    setInput('');

    try {
      const response = await fetch('http://localhost:5000/api/chatbot', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ message: input, language }),
      });

      const data = await response.json();
      const botMessage = { text: data.response, sender: 'bot' };
      setMessages(prev => [...prev, botMessage]);
    } catch (error) {
      console.error('Error:', error);
      const errorMessage = { 
        text: translations[language].error || 'Sorry, I encountered an error. Please try again.', 
        sender: 'bot' 
      };
      setMessages(prev => [...prev, errorMessage]);
    }
  };

  return (
    <div className="chatbot-container">
      <div className="chatbot-header">
        <h2>RapidReach Support</h2>
        <select 
          value={language} 
          onChange={(e) => setLanguage(e.target.value)}
          className="language-select"
        >
          <option value="en">English</option>
          <option value="hi">हिंदी (Hindi)</option>
          <option value="ta">தமிழ் (Tamil)</option>
          <option value="te">తెలుగు (Telugu)</option>
          <option value="kn">ಕನ್ನಡ (Kannada)</option>
        </select>
      </div>

      <div className="chat-messages">
        {messages.length === 0 && (
          <div className="welcome-message">
            {translations[language].welcome}
          </div>
        )}
        {messages.map((message, index) => (
          <div 
            key={index} 
            className={`message ${message.sender === 'user' ? 'user-message' : 'bot-message'}`}
          >
            {message.text}
          </div>
        ))}
      </div>

      <form onSubmit={handleSend} className="chat-input-form">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder={translations[language].placeholder}
        />
        <button type="submit">{translations[language].send}</button>
      </form>
    </div>
  );
};

export default Chatbot; 