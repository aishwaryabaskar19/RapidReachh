import React, { useState } from 'react';
import './Tracking.css';

const Tracking = () => {
    const [trackingId, setTrackingId] = useState('');
    const [trackingInfo, setTrackingInfo] = useState(null);
    const [error, setError] = useState('');
    const [loading, setLoading] = useState(false);

    const handleTrack = async (e) => {
        e.preventDefault();
        setError('');
        setLoading(true);

        try {
            const response = await fetch('http://localhost:5000/track', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ tracking_id: trackingId })
            });

            const data = await response.json();

            if (response.ok) {
                setTrackingInfo(data);
                setError('');
            } else {
                setError(data.error || 'Failed to track parcel');
                setTrackingInfo(null);
            }
        } catch (err) {
            setError('Error connecting to the server');
            setTrackingInfo(null);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="tracking-container">
            <h2>Track Your Parcel</h2>
            
            <form onSubmit={handleTrack} className="tracking-form">
                <div className="input-group">
                    <input
                        type="text"
                        value={trackingId}
                        onChange={(e) => setTrackingId(e.target.value)}
                        placeholder="Enter your tracking ID"
                        required
                    />
                    <button type="submit" disabled={loading}>
                        {loading ? 'Tracking...' : 'Track Now'}
                    </button>
                </div>
            </form>

            {error && <div className="error-message">{error}</div>}

            {trackingInfo && (
                <div className="tracking-result">
                    <h3>Tracking Information</h3>
                    <div className="info-grid">
                        <div className="info-item">
                            <span className="label">Tracking ID:</span>
                            <span className="value">{trackingInfo.tracking_id}</span>
                        </div>
                        <div className="info-item">
                            <span className="label">Status:</span>
                            <span className="value">{trackingInfo.status}</span>
                        </div>
                        <div className="info-item">
                            <span className="label">Current Location:</span>
                            <span className="value">{trackingInfo.current_location}</span>
                        </div>
                        <div className="info-item">
                            <span className="label">Last Updated:</span>
                            <span className="value">{trackingInfo.last_updated}</span>
                        </div>
                        <div className="info-item">
                            <span className="label">Estimated Arrival:</span>
                            <span className="value">{trackingInfo.eta || 'Not available'}</span>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default Tracking; 