import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import Tracking from './components/Tracking';
import Chatbot from './components/Chatbot';
import Auth from './components/Auth';
import './App.css';

function App() {
  const isAuthenticated = !!localStorage.getItem('token');

  return (
    <Router>
      <div className="App">
        <header className="App-header">
          <h1>RapidReach</h1>
        </header>
        <nav className="navbar">
          <div className="nav-brand">RapidReach</div>
          <div className="nav-links">
            <Link to="/">Home</Link>
            <Link to="/tracking">Tracking</Link>
            <Link to="/support">Support</Link>
            {!isAuthenticated ? (
              <Link to="/auth">Login/Register</Link>
            ) : (
              <button 
                onClick={() => {
                  localStorage.removeItem('token');
                  window.location.href = '/';
                }}
                className="logout-button"
              >
                Logout
              </button>
            )}
          </div>
        </nav>

        <main className="main-content">
          <Routes>
            <Route path="/" element={<Tracking />} />
            <Route path="/tracking" element={<Tracking />} />
            <Route path="/support" element={<Chatbot />} />
            <Route path="/auth" element={<Auth />} />
          </Routes>
        </main>
      </div>
    </Router>
  );
}

export default App; 